const Task = require('../models/Task');

// Create a new task
exports.createTask = async (req, res) => {
    try {
        const task = await Task.create(req.body);
        res.status(201).json(task);
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
};

// Update an existing task
exports.updateTask = async (req, res) => {
    try {
        const task = await Task.findByIdAndUpdate(req.params.id, req.body, { new: true });
        if (!task) return res.status(404).json({ message: "Task not found" });
        res.json(task);
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
};

// Mark a task as complete
exports.completeTask = async (req, res) => {
    try {
        const task = await Task.findByIdAndUpdate(req.params.id, { status: 'completed' }, { new: true });
        if (!task) return res.status(404).json({ message: "Task not found" });
        res.json(task);
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
};

// Delete a task
exports.deleteTask = async (req, res) => {
    try {
        const task = await Task.findByIdAndDelete(req.params.id);
        if (!task) return res.status(404).json({ message: "Task not found" });
        res.json({ message: "Task deleted" });
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
};

// List all tasks with optional filters
exports.listTasks = async (req, res) => {
    try {
        const { status, createdAt, age } = req.query;
        const filter = {};
        if (status) filter.status = status;
        if (createdAt) filter.createdAt = { $gte: new Date(createdAt) };
        if (age) filter.age = age;

        const tasks = await Task.find(filter);
        res.json(tasks);
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
};
