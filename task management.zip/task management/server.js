const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const taskRoutes = require('./routes/taskRoutes');
const User = require('./models/User');
const Task = require('./models/Task'); 

const JWT_SECRET = 'your_jwt_secret'; 

const app = express();
app.use(bodyParser.json());

function authenticate(req, res, next) {
  const authHeader = req.headers.authorization;
  if (!authHeader) return res.status(401).json({ message: 'Missing Authorization header' });

  const token = authHeader.split(' ')[1];
  if (!token) return res.status(401).json({ message: 'Token missing' });

  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    req.userId = decoded.userId;
    next();
  } catch (err) {
    return res.status(403).json({ message: 'Invalid or expired token' });
  }
}

// Register
app.post('/api/auth/register', async (req, res) => {
  try {
    const { username, password } = req.body;
    const user = new User({ username, password });
    await user.save();
    res.status(201).json({ message: 'User registered' });
  } catch (err) {
    res.status(400).json({ error: 'Username already exists or invalid data' });
  }
});

// Login
app.post('/api/auth/login', async (req, res) => {
  const { username, password } = req.body;
  const user = await User.findOne({ username });
  const isValid = user && await bcrypt.compare(password, user.password);

  if (!isValid) return res.status(401).json({ message: 'Invalid credentials' });

  const token = jwt.sign({ userId: user._id }, JWT_SECRET, { expiresIn: '1d' });
  res.json({ token });
});

// Protected task creation route
app.post('/api/tasks', authenticate, async (req, res) => {
  try {
    const task = new Task({
      title: req.body.title,
      description: req.body.description,
      priority: req.body.priority,
      dueDate: req.body.dueDate,
      userId: req.userId
    });

    await task.save();
    res.status(201).json(task);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Task listing with filters
app.get('/api/tasks', authenticate, async (req, res) => {
  const { status, from, to, priority, dueFrom, dueTo } = req.query;
  let filter = { userId: req.userId };

  if (status) filter.status = status;
  if (priority) filter.priority = priority;
  if (from || to) {
    filter.createdAt = {};
    if (from) filter.createdAt.$gte = new Date(from);
    if (to) filter.createdAt.$lte = new Date(to);
  }
  if (dueFrom || dueTo) {
    filter.dueDate = {};
    if (dueFrom) filter.dueDate.$gte = new Date(dueFrom);
    if (dueTo) filter.dueDate.$lte = new Date(dueTo);
  }

  try {
    const tasks = await Task.find(filter).sort({ dueDate: 1 }).populate('userId', 'username');
    res.json(tasks);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// This goes in server.js or your taskRoutes.js file

app.get('/api/tasks/:id', authenticate, async (req, res) => {
  const { id } = req.params;

  try {
    const task = await Task.findOne({ _id: id, userId: req.userId });

    if (!task) {
      return res.status(404).json({ message: 'Task not found or not authorized' });
    }

    res.json(task);
  } catch (err) {
    res.status(400).json({ error: 'Invalid task ID or server error' });
  }
});

// 
app.use('/api/tasks', taskRoutes); 

// 
app.get('/', (req, res) => {
  res.send('Task Management API is running ✅');
});

// 
mongoose.connect('mongodb://localhost:27017/taskdb', {
  useNewUrlParser: true,
  useUnifiedTopology: true
})
.then(() => {
  console.log('Connected to MongoDB');
  app.listen(3000, () => console.log('Server running on http://localhost:3000'));
})
.catch(err => console.error('Error connecting to MongoDB:', err));
