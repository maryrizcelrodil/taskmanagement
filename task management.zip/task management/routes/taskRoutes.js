const express = require('express');
const { 
    createTask, 
    updateTask, 
    completeTask, 
    deleteTask, 
    listTasks 
} = require('../controllers/taskController');

const router = express.Router();

router.post('/', createTask);
router.put('/:id', updateTask);
router.patch('/:id/complete', completeTask);
router.delete('/:id', deleteTask);
router.get('/', listTasks);

module.exports = router;
