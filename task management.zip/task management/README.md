# 📝 Task Management API

A simple RESTful API to manage tasks with user authentication, task priority, due dates, and filtering features.

---

## 🚀 Features

- User registration & login with JWT authentication (bonus)
- Create, update, delete, and complete tasks
- Task priority: low, medium, high (bonus)
- Due date and reminder simulation
- Filter tasks by:
  - Status
  - Creation date range
  - Due date range
  - Priority (bonus)

---

## 🛠️ Tech Stack

- Node.js
- Express.js
- MongoDB + Mongoose
- JSON Web Tokens (JWT)
- bcrypt for password hashing

---

## Setup Instructions

### 1. Clone the Repository

```bash
git clone https://github.com/maryrizcelrodil/Task.git

### 2. Install dependencies
    npm init -y
    npm install express mongoose body-parser

### 3. Run the MongoDB locally.
### 4. Run the server.
    node server.js
    Server should now run at: http://localhost:3000

## Setup/Test in Postman (API docs)
Bonus feature: User authetication

### 1. Register a User
    Endpoint: POST http://localhost:3000/api/auth/register
    Body (JSON):
    {
        "username": "testuser",
        "password": "test123"
    }

    Expected Response: 
    {
        "message": "User registered"
    }

### 2. tep 2: Log In to Get the JWT Token
    Endpoint: POST http://localhost:3000/api/auth/login
    Body (JSON):
    {
     "username": "testuser",
     "password": "test123"
    }

    Expected Response:
    {
        "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
    }

### 3. Test a Protected Route (e.g., Create a Task)
    Endpoint: POST http://localhost:3000/api/tasks
    Headers:
    Key: Authorization
    Value: Bearer <paste the token here>
    Body (JSON):
    {
        "title": "test",
        "description": "task test",
        "priority": "high",
        "dueDate": "2025-05-25"
    }

    Expected Response:
    {
        "_id": "some-task-id",
        "title": "test",
        "description": "test",
        "priority": "high",
        "dueDate": "2025-05-25T00:00:00.000Z",
        "userId": "your-user-id",
  ...
    }

### CREATE, UPDATE, MARK, DELATE, and LIST tasks

### 1. Create a new task
    Method: POST
    URL: http://localhost:3000/api/tasks
    Go to Body → choose raw → JSON.
    Paste this JSON:
        {
            "title": "test",
            "description": "Added username",
            "priority": "medium",
            "dueDate": "2025-05-25"
        }

### 2. Update an existing task
    Method: PUT
    URL: http://localhost:3000/api/tasks/<TASK_ID>
    Go to Body → choose raw → JSON.
    Paste full task data (replace as needed) Example:
        {
            "title": "test",
            "description": "Added username",
            "priority": "medium",
            "dueDate": "2025-05-25"
            "status": "completed"
        }

### 3. Mark a task as complete
    Method: PATCH
    URL: http://localhost:3000/api/tasks/<TASK_ID>/complete
    Replace <TASK_ID> with the actual _id from your database
    Example: http://localhost:3000/api/tasks/6651d135a6a03bd93c48de5e/complete

### 4. Delete a task
    Method: DELETE
    URL: http://localhost:3000/api/tasks/<TASK_ID>
    Again, replace <TASK_ID> with the ID of the task you want to delete.
    Example:
    http://localhost:3000/api/tasks/6651d135a6a03bd93c48de5e

    No (JSON) Body Needed.

    Expected response:
    { "message": "Task deleted" }

### 5. Get all the task lists (with filter status, creation date)
    Method: GET
    URL: http://localhost:3000/api/tasks

Sample response:
    {
        "_id": "6651d135a6a03bd93c48de5e",
        "title": "Test Task",
        "description": "Sample",
        "status": "pending",
        "createdAt": "2025-05-18T10:22:30.000Z",
        "__v": 0
    }

### 6. Get all the task lists with bonus filter (task priority: low, medium, high) and due date field.
    Method: GET
    URL: http://localhost:3000/api/tasks
    Sample response:
    {
        "title": "ricssssssss",
        "status": "pending",
        "priority": "medium",
        "dueDate": "2025-05-26T00:00:00.000Z",
        "userId": "682ccfa80d093b6c25cac3da",
        "_id": "682cd6a88ddb3de964afb0e8",
        "createdAt": "2025-05-20T19:23:20.197Z",
        "__v": 0
    }

### 7. Retrieve a specific task.
    Method: GET
    URL: http://localhost:3000/api/tasks/id

    Sample response: 
   {
        "_id": "682cd01d0d093b6c25cac3de",
        "title": "test",
        "description": "test",
        "status": "pending",
        "priority": "high",
        "dueDate": "2025-05-25T00:00:00.000Z",
        "userId": "682ccfa80d093b6c25cac3da",
        "createdAt": "2025-05-20T18:55:25.542Z",
        "__v": 0
    }



        



